﻿namespace Lab_2
{
    public abstract class Equation
    {
        public abstract double CalculateValue(double value);
    }
}
